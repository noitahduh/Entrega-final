let products = JSON.parse(localStorage.getItem('products')); 

if (!products) {
    products = [
        { 
            id: 1, 
            title: 'Super Mario Bros (1985)', 
            price: 53.00, 
            orderCode: '69272', 
            manufacturer: 'Hator', 
            color: 'Black', 
            images: [
                'https://assets-prd.ignimgs.com/2022/01/08/smb-nesart-1641603921866.jpg?width=300&crop=1%3A1%2Csmart&auto=webp',
                'https://www.nintendo.com/eu/media/images/10_share_images/games_15/virtual_console_nintendo_3ds_7/SI_3DSVC_SuperMarioBros.jpg',
                'https://cdn.computerhoy.com/sites/navi.axelspringer.es/public/media/image/2018/09/super-mario-bros.jpg',
                'https://images.milenio.com/16Ep-a-YnKxV4mzfKYKASHCS8LU=/345x194/uploads/media/2020/07/13/super-mario-bros-videojuego-caro_29_42_628_391.jpg'
            ],
            reviews: 15,
        },
        
    ];

    localStorage.setItem('products', JSON.stringify(products));
    console.log('Productos iniciales guardados en Local Storage.');
} else {
    console.log('Productos cargados desde Local Storage:', products);
}
