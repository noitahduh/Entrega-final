document.addEventListener("DOMContentLoaded", () => {
   
    const params = new URLSearchParams(window.location.search);
    const productId = params.get("id");  

   
    const products = JSON.parse(localStorage.getItem("products")) || [];

    const product = products.find(item => item.id == productId);

    if (product) {
       
        document.getElementById("main-image").src = product.images[0]; 
        document.getElementById("title").innerText = product.title;
        document.getElementById("price").innerText = `Precio: $${product.price || "N/A"}`;
        document.getElementById("order-code").innerText = `Código: ${product.orderCode || "N/A"}`;
        document.getElementById("manufacturer").innerText = `Fabricante: ${product.manufacturer || "Desconocido"}`;
        document.getElementById("color").innerText = `Color: ${product.color || "N/A"}`;
        document.getElementById("reviews-count").innerText = `${product.reviews || 0} opiniones`;

        const imagesSection = document.getElementById("images-section");
        product.images.forEach((imageUrl, index) => {
            if (index !== 0) { 
                const imgElement = document.createElement("img");
                imgElement.src = imageUrl;
                imgElement.alt = `Imagen adicional ${index + 1}`;
                imagesSection.appendChild(imgElement);
            }
        });

        
        const favoriteButton = document.getElementById("favorite-button");
        favoriteButton.addEventListener("click", () => {
            
            const favorites = JSON.parse(localStorage.getItem('favorites')) || [];

            
            const isAlreadyFavorite = favorites.some(fav => fav.id === product.id);
            
            if (!isAlreadyFavorite) {
                favorites.push(product);
                localStorage.setItem('favorites', JSON.stringify(favorites));
                alert("Producto añadido a tus favoritos");
            } else {
                alert("Este producto ya está en tus favoritos");
            }
        });

    } else {
     
        document.querySelector(".content-wrapper").innerHTML = `
            <p>Producto no encontrado. Por favor, regresa al <a href="categoria.html">Marketplace</a>.</p>
        `;
    }
});