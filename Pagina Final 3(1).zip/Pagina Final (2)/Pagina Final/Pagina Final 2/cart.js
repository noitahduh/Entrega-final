let cart = JSON.parse(localStorage.getItem('cart')) || [];


function updateCartCount() {
    document.getElementById('cart-count').textContent = cart.length;
}

function addToCart(product) {
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
}


function displayCartItems() {
    const cartItemsDiv = document.getElementById('cart-items');
    const totalPriceP = document.getElementById('total-price');
    cartItemsDiv.innerHTML = '';
    let total = 0;

    if (cart.length === 0) {
        cartItemsDiv.innerHTML = '<p>Your cart is empty.</p>';
        totalPriceP.textContent = '';
        return;
    }

    cart.forEach((item, index) => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('cart-item'); 

        itemDiv.innerHTML = `
            <div class="cart-card">
                <img src="${item.image}" alt="${item.name}" class="cart-image">
                <div class="cart-details">
                    <p class="cart-name">${item.name}</p>
                    <p class="cart-price">$${item.price}</p>
                    <button class="remove-button" onclick="removeFromCart(${index})">Remove</button>
                </div>
            </div>
        `;

        cartItemsDiv.appendChild(itemDiv);
        total += item.price;
    });

    totalPriceP.textContent = `Total: $${total.toFixed(2)}`;
}


function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    displayCartItems();
    updateCartCount();
}


document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();

 
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function () {
            const productCard = this.closest('.product-card');
            const productName = productCard.getAttribute('data-name');
            const productPrice = parseFloat(productCard.querySelector('.price').textContent.replace('$', ''));
            const productImage = productCard.querySelector('img').src;

            const product = { name: productName, price: productPrice, image: productImage };

            addToCart(product);
            alert(`${productName} has been added to your cart!`);
        });
    });

    if (document.getElementById('cart-items')) {
        displayCartItems();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();

    if (document.getElementById('cart-items')) {
        displayCartItems();
    }

  
    const checkoutButton = document.getElementById('checkout-button');
    if (checkoutButton) {
        checkoutButton.addEventListener('click', function () {
            if (cart.length === 0) {
                alert('Your cart is empty! Add some products before checking out.');
                return;
            }

          
            alert('Thank you for your purchase!');
            
       
            cart = [];
            localStorage.setItem('cart', JSON.stringify(cart));
            displayCartItems();
            updateCartCount();
        });
    }
});



