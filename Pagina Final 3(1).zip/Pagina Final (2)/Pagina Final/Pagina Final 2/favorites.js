document.addEventListener("DOMContentLoaded", () => {
    const favoriteList = document.getElementById("favorite-list");

   
    const favorites = JSON.parse(localStorage.getItem("favorites")) || [];

    if (favorites.length > 0) {
      
        favorites.forEach(favorite => {
            const item = document.createElement("div");
            item.classList.add("favorite-item");
            item.innerHTML = `
                <img src="${favorite.images[0]}" alt="${favorite.title}">
                <h2>${favorite.title}</h2>
                <p>Precio: $${favorite.price}</p>
                <button onclick="removeFromFavorites(${favorite.id})">Eliminar</button>
            `;
            favoriteList.appendChild(item);
        });
    } else {
        favoriteList.innerHTML = `<p>No tienes productos favoritos. ¡Añade algunos desde el <a href="categoria.html">Marketplace</a>!</p>`;
    }
});


function removeFromFavorites(productId) {
    let favorites = JSON.parse(localStorage.getItem("favorites")) || [];
    favorites = favorites.filter(product => product.id !== productId);
    localStorage.setItem("favorites", JSON.stringify(favorites));
    alert("Producto eliminado de favoritos");
    location.reload(); 
}

document.addEventListener("DOMContentLoaded", () => {
    const favoriteList = document.getElementById("favorite-list");
    const favorites = JSON.parse(localStorage.getItem('favorites')) || [];

    if (favorites.length === 0) {
        favoriteList.innerHTML = "<p>No tienes juegos en favoritos aún.</p>";
    } else {
        favorites.forEach(favorite => {
            const item = document.createElement("div");
            item.classList.add("favorite-item");
            item.innerHTML = `
                <a href="buy.html?id=${favorite.id}" class="favorite-link">
                    <img src="${favorite.image}" alt="${favorite.title}">
                    <h2>${favorite.title}</h2>
                    <p>${favorite.description || ""}</p>
                </a>
                <button class="remove-favorite">Eliminar</button>
            `;
            favoriteList.appendChild(item);

            item.querySelector(".remove-favorite").addEventListener("click", () => {
                const updatedFavorites = favorites.filter(fav => fav.id !== favorite.id);
                localStorage.setItem('favorites', JSON.stringify(updatedFavorites));
                item.remove();
            });
        });
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const favoriteList = document.getElementById("favorite-list");
    const favorites = JSON.parse(localStorage.getItem("favorites")) || [];

    if (favorites.length === 0) {
        favoriteList.innerHTML = "<p>No tienes juegos en favoritos aún.</p>";
    } else {
        favorites.forEach(favorite => {
            const item = document.createElement("div");
            item.classList.add("favorite-item");

            item.innerHTML = `
                <a href="#" class="favorite-link" data-id="${favorite.id}">
                    <img src="${favorite.image}" alt="${favorite.title}">
                    <h2>${favorite.title}</h2>
                    <p>${favorite.description || ""}</p>
                </a>
                <button class="remove-favorite">Eliminar</button>
            `;

            favoriteList.appendChild(item);

            // Agregar evento para el clic en el enlace del producto
            item.querySelector(".favorite-link").addEventListener("click", (event) => {
                event.preventDefault();
                // Guardar datos del producto en localStorage
                localStorage.setItem("productDetail", JSON.stringify(favorite));
                // Redirigir a la página de detalle
                window.location.href = "product-detail.html";
            });

            // Botón para eliminar favoritos
            item.querySelector(".remove-favorite").addEventListener("click", () => {
                const updatedFavorites = favorites.filter(fav => fav.id !== favorite.id);
                localStorage.setItem("favorites", JSON.stringify(updatedFavorites));
                item.remove();
            });
        });
    }
});

